package com.example.traductor_local;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private Button btnSaludo;
    private Button btnAbecedario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSaludo = findViewById(R.id.btnSaludar);
        btnAbecedario = findViewById(R.id.btnAbecedario);

        btnSaludo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SaludoActivity.class);
                startActivity(intent);
            }
        });

        btnAbecedario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AbecedarioActivity.class);
                startActivity(intent);
            }
        });
    }
}
