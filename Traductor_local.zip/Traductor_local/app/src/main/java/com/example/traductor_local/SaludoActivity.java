package com.example.traductor_local;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Locale;

public class SaludoActivity extends AppCompatActivity {
    private TextView txtResultado;
    private VideoView videoSeñas;
    private Button btnEscuchar, btnProcesarTexto;
    private EditText edtTexto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saludo);

        txtResultado = findViewById(R.id.txtResultado);
        videoSeñas = findViewById(R.id.videoSeñas);
        btnEscuchar = findViewById(R.id.btnEscuchar);
        btnProcesarTexto = findViewById(R.id.btnProcesarTexto);
        edtTexto = findViewById(R.id.edtTexto);

        btnEscuchar.setOnClickListener(v -> iniciarReconocimientoVoz());
        btnProcesarTexto.setOnClickListener(v -> traducirALenguajeDeSeñas(edtTexto.getText().toString()));
    }

    private void iniciarReconocimientoVoz() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Di algo...");
        startActivityForResult(intent, 100);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            ArrayList<String> resultado = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            String textoReconocido = resultado.get(0);
            txtResultado.setText("Texto reconocido: " + textoReconocido);
            traducirALenguajeDeSeñas(textoReconocido);
        }
    }

    private void traducirALenguajeDeSeñas(String texto) {
        String textoNormalizado = quitarAcentos(texto.toLowerCase());
        int videoResId = 0;

        switch (textoNormalizado) {
            case "hola":
                videoResId = R.raw.video_hola;
                break;
            case "como estas":
                videoResId = R.raw.video_como_estas;
                break;
            case "buenos dias":
                videoResId = R.raw.video_buenos_dias;
                break;
            case "buenas tardes":
                videoResId = R.raw.video_buenas_tardes;
                break;
            case "buenas noches":
                videoResId = R.raw.video_buenas_noches;
                break;
            default:
                txtResultado.setText("No se encontró un video para esta frase.");
                videoSeñas.setVisibility(View.GONE);
                return;
        }

        reproducirVideo("android.resource://" + getPackageName() + "/" + videoResId);
    }

    private void reproducirVideo(String videoUri) {
        videoSeñas.setVisibility(View.VISIBLE);
        videoSeñas.setVideoURI(Uri.parse(videoUri));
        videoSeñas.start();
        videoSeñas.setOnCompletionListener(mp -> videoSeñas.setVisibility(View.GONE));
    }

    private String quitarAcentos(String input) {
        return Normalizer.normalize(input, Normalizer.Form.NFD).replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }
}
