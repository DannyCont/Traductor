package com.example.traductor_local;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class AbecedarioActivity extends AppCompatActivity {

    private Button btnA, btnB, btnC, btnD, btnE, btnF, btnG, btnH, btnI, btnJ, btnK, btnL, btnM, btnN, btnO, btnP, btnQ, btnR, btnS, btnT, btnU, btnV, btnW, btnX, btnY, btnZ;
    private ImageView imgSignLanguage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abecedario);

        // Inicializar los botones
        btnA = findViewById(R.id.btnA);
        btnB = findViewById(R.id.btnB);
        btnC = findViewById(R.id.btnC);
        btnD = findViewById(R.id.btnD);
        btnE = findViewById(R.id.btnE);
        btnF = findViewById(R.id.btnF);
        btnG = findViewById(R.id.btnG);
        btnH = findViewById(R.id.btnH);
        btnI = findViewById(R.id.btnI);
        btnJ = findViewById(R.id.btnJ);
        btnK = findViewById(R.id.btnK);
        btnL = findViewById(R.id.btnL);
        btnM = findViewById(R.id.btnM);
        btnN = findViewById(R.id.btnN);
        btnO = findViewById(R.id.btnO);
        btnP = findViewById(R.id.btnP);
        btnQ = findViewById(R.id.btnQ);
        btnR = findViewById(R.id.btnR);
        btnS = findViewById(R.id.btnS);
        btnT = findViewById(R.id.btnT);
        btnU = findViewById(R.id.btnU);
        btnV = findViewById(R.id.btnV);
        btnW = findViewById(R.id.btnW);
        btnX = findViewById(R.id.btnX);
        btnY = findViewById(R.id.btnY);
        btnZ = findViewById(R.id.btnZ);

        // ImageView para mostrar la traducción
        imgSignLanguage = findViewById(R.id.imgSignLanguage);

        // Establecer el comportamiento al hacer clic en los botones
        setButtonClickListener(btnA, R.drawable.sign_a);
        setButtonClickListener(btnB, R.drawable.sign_b);
        setButtonClickListener(btnC, R.drawable.sign_c);
        setButtonClickListener(btnD, R.drawable.sign_d);
        setButtonClickListener(btnE, R.drawable.sign_e);
        setButtonClickListener(btnF, R.drawable.sign_f);
        setButtonClickListener(btnG, R.drawable.sign_g);
        setButtonClickListener(btnH, R.drawable.sign_h);
        setButtonClickListener(btnI, R.drawable.sign_i);
        setButtonClickListener(btnJ, R.drawable.sign_j);
        setButtonClickListener(btnK, R.drawable.sign_k);
        setButtonClickListener(btnL, R.drawable.sign_l);
        setButtonClickListener(btnM, R.drawable.sign_m);
        setButtonClickListener(btnN, R.drawable.sign_n);
        setButtonClickListener(btnO, R.drawable.sign_o);
        setButtonClickListener(btnP, R.drawable.sign_p);
        setButtonClickListener(btnQ, R.drawable.sign_q);
        setButtonClickListener(btnR, R.drawable.sign_r);
        setButtonClickListener(btnS, R.drawable.sign_s);
        setButtonClickListener(btnT, R.drawable.sign_t);
        setButtonClickListener(btnU, R.drawable.sign_u);
        setButtonClickListener(btnV, R.drawable.sing_v);
        setButtonClickListener(btnW, R.drawable.sign_w);
        setButtonClickListener(btnX, R.drawable.sign_x);
        setButtonClickListener(btnY, R.drawable.sign_y);
        setButtonClickListener(btnZ, R.drawable.sign_z);
    }

    private void setButtonClickListener(Button button, final int drawableResId) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgSignLanguage.setVisibility(View.VISIBLE); // Mostrar la imagen
                imgSignLanguage.setImageResource(drawableResId); // Cambiar la imagen
            }
        });
    }
}
